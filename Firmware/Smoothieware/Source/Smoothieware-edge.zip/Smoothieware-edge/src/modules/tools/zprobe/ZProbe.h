/*
      This file is part of Smoothie (http://smoothieware.org/). The motion control part is heavily based on Grbl (https://github.com/simen/grbl).
      Smoothie is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
      Smoothie is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
      You should have received a copy of the GNU General Public License along with Smoothie. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef ZPROBE_H_
#define ZPROBE_H_

#include "Module.h"
#include "Pin.h"

#include <vector>

// defined here as they are used in multiple files
#define zprobe_checksum            CHECKSUM("zprobe")
#define leveling_strategy_checksum CHECKSUM("leveling-strategy")

class StepperMotor;
class Gcode;
class StreamOutput;
class LevelingStrategy;

class ZProbe: public Module
{

public:
    ZProbe() : running(false), invert_override(false) {};
    virtual ~ZProbe() {};

    void on_module_loaded();
    void on_gcode_received(void *argument);
    void acceleration_tick(void);

    bool wait_for_probe(int& steps);
    bool run_probe(int& steps, float feedrate, float max_dist= -1, bool reverse= false);
    bool run_probe(int& steps, bool fast= false) { return run_probe(steps, fast ? this->fast_feedrate : this->slow_feedrate); }
    bool return_probe(int steps, bool reverse= false);
    bool doProbeAt(int &steps, float x, float y);
    float probeDistance(float x, float y);

    void coordinated_move(float x, float y, float z, float feedrate, bool relative=false);
    void home();

    bool getProbeStatus() { return this->pin.get(); }
    float getSlowFeedrate() const { return slow_feedrate; }
    float getFastFeedrate() const { return fast_feedrate; }
    float getProbeHeight() const { return probe_height; }
    float getMaxZ() const { return max_z; }
    float zsteps_to_mm(float steps);

private:
    void on_config_reload(void *argument);
    void accelerate(int c);
    void probe_XYZ(Gcode *gc, int axis);
    uint32_t read_probe(uint32_t dummy);
    volatile float current_feedrate;
    float slow_feedrate;
    float fast_feedrate;
    float return_feedrate;
    float probe_height;
    float max_z;

    Pin pin;
    std::vector<LevelingStrategy*> strategies;
    uint8_t debounce_count;

    volatile struct {
        volatile bool running:1;
        bool is_delta:1;
        bool is_rdelta:1;
        bool probing:1;
        bool reverse_z:1;
        bool invert_override:1;
        volatile bool probe_detected:1;
    };
};

#endif /* ZPROBE_H_ */
